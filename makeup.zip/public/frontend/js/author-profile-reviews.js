(function($){
	$('.tooltip').tooltipster({
		animation: 'grow',
		delay: 100,
		position: 'top'
	});
})(jQuery);