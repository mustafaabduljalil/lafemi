<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Homepage
Route::get('/',['as' => 'home', 'uses' => 'HomeController@index']);

// Admin Routes
Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});

// Composer Routes
Route::get('composer','\Lubusin\Decomposer\Controllers\DecomposerController@index')->middleware('nice_artisan');

// Auth Routes
Auth::routes();

// Home Route
Route::get('/home', 'HomeController@index')->name('home');

// OAuth Routes
Route::get('auth/{provider}', 'Auth\AuthController@redirectToProvider');
Route::get('auth/{provider}/callback', 'Auth\AuthController@handleProviderCallback');