<?php echo $__env->make('voyager-frontend::partials.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('voyager-frontend::partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('voyager-frontend::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
