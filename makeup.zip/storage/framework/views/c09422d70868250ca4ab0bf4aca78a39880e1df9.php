<!-- BANNER -->
<div class="banner-wrap">
	<section class="banner">
		<h5>Welcome to</h5>
		
		<h1>The Biggest <span>Marketplace</span></h1>
		
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
		
		<img src="<?php echo e(asset('frontend/images/top_items.png')); ?>" alt="banner-img">

		<!-- SEARCH WIDGET -->
		<div class="search-widget">
			<form class="search-widget-form">
				<input type="text" name="category_name" placeholder="Search goods or services here...">
				
				<label for="categories" class="select-block">
					<select name="categories" id="categories">
						<option value="0">All Categories</option>
						<option value="1">PSD Templates</option>
						<option value="2">Hero Images</option>
						<option value="3">Shopify</option>
						<option value="4">Icon Packs</option>
						<option value="5">Graphics</option>
						<option value="6">Flyers</option>
						<option value="7">Backgrounds</option>
						<option value="8">Social Covers</option>
					</select>
					
					<!-- SVG ARROW -->
					<svg class="svg-arrow">
						<use xlink:href="#svg-arrow"></use>
					</svg>
					<!-- /SVG ARROW -->
				</label>
				
				<button class="button medium dark">Search Now!</button>
			</form>
		</div>
		<!-- /SEARCH WIDGET -->
	</section>
</div>
<!-- /BANNER -->