<!doctype html>
<html lang="en" class="no-js">
<head>
		<title><?php echo $__env->yieldContent('meta_title', setting('site.title')); ?></title>
		<meta name="description" content="<?php echo $__env->yieldContent('meta_description', setting('site.description')); ?> - <?php echo e(setting('site.title')); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<!-- Open Graph -->
		<meta property="og:site_name" content="<?php echo e(setting('site.title')); ?>" />
		<meta property="og:title" content="<?php echo $__env->yieldContent('meta_title'); ?>" />
		<meta property="og:type" content="website" />
		<meta property="og:url" content="<?php echo e(url('/')); ?>" />
		<meta property="og:image" content="<?php echo $__env->yieldContent('meta_image', url('/') . '/images/apple-touch-icon.png'); ?>" />
		<meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', setting('site.description')); ?>" />

		<!-- Icons -->
		<meta name="msapplication-TileImage" content="<?php echo e(url('/')); ?>/ms-tile-icon.png" />
		<meta name="msapplication-TileColor" content="#8cc641" />
		<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.ico" />
		<link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/')); ?>/images/apple-touch-icon.png" />

		<!-- Styles -->
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/css/app.css">

		<?php if(setting('site.google_analytics_tracking_id')): ?>
				<!-- Google Analytics (gtag.js) -->
				<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(setting('site.google_analytics_tracking_id')); ?>"></script>
				<script>
						window.dataLayer = window.dataLayer || [];
						function gtag(){dataLayer.push(arguments);}
						gtag('js', new Date());

						gtag('config', '<?php echo e(setting('site.google_analytics_tracking_id')); ?>');
				</script>
		<?php endif; ?>

        <?php if(setting('admin.google_recaptcha_site_key')): ?>
            <script src='https://www.google.com/recaptcha/api.js' async defer></script>
            <script>
                function setFormId(formId) {
                    window.formId = formId;
                }

                function onSubmit(token) {
                    document.getElementById(window.formId).submit();
                }
            </script>
     <?php endif; ?>
</head>
<body>
